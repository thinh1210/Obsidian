---
title: "IELTS Writing Master Index"
tags:
  - ielts/writing
  - master_index
---

# 📖 IELTS Writing Master Hub: Kho Bài Mẫu & Phân Tích Chuyên Sâu

Chào mừng bạn đến với hệ sinh thái học **IELTS Writing** được chuẩn hóa và lưu trữ trực tiếp trong Obsidian Vault.

> [!TIP] Cấu Trúc Khóa Học Writing
> Mỗi thư mục dạng bài đều sở hữu file **Cẩm nang chiến lược (`0_Index.md`)** tổng hợp:
> 1. **Cấu trúc khung chuẩn 4 đoạn**
> 2. **Bảng từ vựng & Collocations cốt lõi**
> 3. **Ngân hàng mẫu câu ăn điểm (Sentence Frames)**
> 4. **Bảng mục lục các bài mẫu Band 8.5 - 9.0 đã được phân tích 5 chiều sâu sắc**

---

## 📊 1. IELTS Writing Task 1 (Academic Reports) — `27 bài mẫu`

| Dạng Bài (Task 1 Type) | Số Lượng Bài Đã Có | Cẩm Nang & Mục Lục Chi Tiết |
| :--- | :---: | :--- |
| 📊 **Bar Chart (Biểu đồ cột)** | `4 bài mẫu` | [[task1/bar_chart/0_Bar_Chart_Index\|Cẩm nang & Mục lục 🔗]] |
| 📈 **Line Graph (Biểu đồ đường)** | `4 bài mẫu` | [[task1/line_graph/0_Line_Graph_Index\|Cẩm nang & Mục lục 🔗]] |
| 🥧 **Pie Chart (Biểu đồ tròn)** | `4 bài mẫu` | [[task1/pie_chart/0_Pie_Chart_Index\|Cẩm nang & Mục lục 🔗]] |
| 📋 **Table (Bảng số liệu)** | `4 bài mẫu` | [[task1/table/0_Table_Index\|Cẩm nang & Mục lục 🔗]] |
| 🗺️ **Map (Bản đồ biến đổi)** | `4 bài mẫu` | [[task1/map/0_Map_Index\|Cẩm nang & Mục lục 🔗]] |
| ⚙️ **Process (Quy trình sản xuất / Tự nhiên)** | `4 bài mẫu` | [[task1/process/0_Process_Index\|Cẩm nang & Mục lục 🔗]] |
| 📑 **Mixed Chart (Biểu đồ kết hợp)** | `3 bài mẫu` | [[task1/mixed_chart/0_Mixed_Chart_Index\|Cẩm nang & Mục lục 🔗]] |

---

## 📝 2. IELTS Writing Task 2 (Academic Essays) — `23 bài mẫu`

| Dạng Bài (Task 2 Type) | Số Lượng Bài Đã Có | Cẩm Nang & Mục Lục Chi Tiết |
| :--- | :---: | :--- |
| ⚖️ **Agree or Disagree (Quan điểm / Opinion)** | `5 bài mẫu` | [[task2/agree_disagree/0_Agree_Disagree_Index\|Cẩm nang & Mục lục 🔗]] |
| 👥 **Discuss Both Views (Thảo luận 2 mặt)** | `5 bài mẫu` | [[task2/discuss_both_views/0_Discuss_Both_Views_Index\|Cẩm nang & Mục lục 🔗]] |
| 🔍 **Cause / Problem & Solution (Nguyên nhân & Giải pháp)** | `5 bài mẫu` | [[task2/problem_solution/0_Problem_Solution_Index\|Cẩm nang & Mục lục 🔗]] |
| ⚖️ **Advantages & Disadvantages (Lợi ích & Bất lợi)** | `4 bài mẫu` | [[task2/advantages_disadvantages/0_Advantages_Disadvantages_Index\|Cẩm nang & Mục lục 🔗]] |
| ❓ **Direct Questions (Câu hỏi trực tiếp / Hai phần)** | `4 bài mẫu` | [[task2/direct_questions/0_Direct_Questions_Index\|Cẩm nang & Mục lục 🔗]] |

---

> [!TIP] 🪜 Lộ Trình Học Tập Phân Tầng Theo Cấp Độ (Learning Tracks)
> Để tránh bị quá tải bởi các bài mẫu điểm cao, bạn hãy chọn lộ trình phù hợp với mục tiêu hiện tại của mình:
> 
> 0. 🛑 **Nền tảng sống còn (Chống mất điểm oan):** Nắm vững quy tắc dấu phẩy trước/sau *and*, cách dùng *However / Therefore*, diệt sạch 3 lỗi tối kỵ (*Comma Splice, Run-on, Fragment*) và 8 cạm bẫy dịch thô từ tiếng Việt:  
>    👉 [[Common_Sentence_Errors_and_Punctuation_Guide|Đại Cẩm Nang Sửa Lỗi Viết Câu & Quy Tắc Đặt Dấu Câu Trong Tiếng Anh 🔗]]
> 
> 1. 🟢 **Chặng 1 (Band 5.0 ➔ 6.5):** Diệt sạch lỗi ngữ pháp cơ bản, sử dụng các **khung câu an toàn tuyệt đối**, luyện **bậc thang paraphrase từng nấc** và đọc các bài mẫu đối chiếu 3 band điểm:  
>    👉 [[Band_Progression_Guide_5_to_7.5|Cẩm Nang Nâng Band Từng Bậc: Lộ Trình Từ Band 5.0 Lên 6.0, 6.5, 7.0 & 7.5 🔗]]
> 
> 2. 👑 **Chặng 2 (Band 7.0 ➔ 9.0):** Trau chuốt văn phong học thuật, làm chủ các cấu trúc câu phức đa tầng, mệnh đề phân từ, đại từ quan hệ bao trùm và collocations C1-C2:  
>    👉 [[Master_Structures_Task1_and_Task2|Đại Cẩm Nang Cấu Trúc Câu & Ngữ Pháp IELTS Writing Task 1 & Task 2 (Band 8.5 - 9.0) 🔗]]

---

## 💡 3. Cơ Chế Thêm Bài Mới & Tương Tác Cùng Trợ Lý AI

Bạn có thể tương tác bất cứ lúc nào với hai kịch bản sau:

### Kịch bản 1: "Thêm bài mẫu cho dạng X"
- **Cách yêu cầu:** *"Thêm 2 bài mẫu Task 2 dạng Agree/Disagree về chủ đề Environment và Technology giúp tôi."*
- **Hệ thống sẽ:** Tìm/cào bài mẫu band 9 chuẩn mực, phân tích 5 chiều (Dàn ý, Bài mẫu, Từ vựng C1-C2, Ngữ pháp, Hướng dẫn tự viết), lưu thành `Sample_XX_[Topic].md` và tự động cập nhật bảng Index của thư mục đó.

### Kịch bản 2: Bạn đưa đề thi cụ thể
- **Cách yêu cầu:** *"Tôi có đề này: [Dán đề bài hoặc tải ảnh biểu đồ Task 1]. Hãy viết bài mẫu Band 8.5+ và phân tích thật kỹ giúp tôi."*
- **Hệ thống sẽ:**
  1. Phân loại đề vào đúng thư mục dạng bài tương ứng.
  2. Bẻ khóa đề bài, dựng dàn ý tư duy (Idea Generation & Brainstorming).
  3. Viết bài mẫu Band 8.5 - 9.0 chuẩn mực, tự nhiên, không gượng ép.
  4. Trích xuất bảng từ vựng, cụm Collocations đắt giá, cấu trúc câu ngữ pháp nâng cao.
  5. Viết hướng dẫn tự viết chi tiết và cập nhật file Index.

---

## 🔗 Liên Kết Kho Dữ Liệu Obsidian Khác
- 📂 **Kho Từ Vựng Chủ Đề:** [[English/Vocabulary Topics/]]
- 📐 **Kho Ngữ Pháp & Liên Kết Câu:** [[English/Grammar & Cohesion/]]
  - 🔬 **Cẩm Nang Mổ Xẻ Mệnh Đề & Câu Dài:** [[English/Grammar & Cohesion/2. Sentence Structures & Writing/2.4. Complex Sentences & Clause Breakdown.md|2.4. Complex Sentences & Clause Breakdown 🔗]]
  - 🔄 **Cẩm Nang Paraphrase & Biến Đổi Câu:** [[English/Grammar & Cohesion/2. Sentence Structures & Writing/2.5. Paraphrasing Mastery & Sentence Transformations.md|2.5. Paraphrasing Mastery & Sentence Transformations 🔗]]
  - 👨‍🏫 **Masterclass Paraphrase Cả Đoạn Văn:** [[English/Grammar & Cohesion/2. Sentence Structures & Writing/2.6. Paragraph Paraphrasing & Discourse Rewriting.md|2.6. Paragraph Paraphrasing & Discourse Rewriting 🔗]]
- 🎙️ **Luyện Nói IELTS Speaking:** [[English/.agent/SKILL/ielts-speaking-generator/]]
