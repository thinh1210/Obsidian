---
tags:
  - review
  - flashcards
  - flashcards/3-People-and-Relationships/CHILDREN
  - review/3-People-and-Relationships/CHILDREN
---
# Daughter
*noun*
> /ˈdɔː.tər/

![[daughter.mp3]]

---
**Level:** A1 | **Ngữ cảnh:** Daily | **Chủ đề:** CHILDREN | **Phân nhóm:** Giai đoạn thơ ấu, Tuổi tác & Tình thương

## 🗂️ Flashcard
Daughter::Con gái *(Phát âm: /ˈdɔː.tər/)* ![[daughter.mp3]]<br><br>👪 **Word Family:** Daughter-in-law (n)<br><br>💬 **Ví dụ:** She is my daughter.<br>*(-> Cô ấy là con gái tôi.)*

## 📌 Ý nghĩa (Meaning)
- **EN:** A girl or woman in relation to her parents.
- **VN:** Con gái.

## 🧠 Mẹo nhớ (Mnemonics)
💡 Daughter giống đó tớ (đó là tớ), con gái tớ.

## 🧩 Cụm từ thường đi kèm (Collocations)
- `only daughter`: con gái duy nhất
- `doting daughter`: cô con gái hiếu thảo yêu thương
- `daughter-in-law`: con dâu
- `eldest daughter`: con gái cả

## 🎬 Ví dụ thực tế (Real-world Examples)
1. 💬 *Daily:* She is my daughter.
   *-> Cô ấy là con gái tôi.*
2. 💼 *Work/Academic:* Her daughter graduated today.
   *-> Con gái cô ấy đã tốt nghiệp hôm nay.*
3. 🎬 *Media/Movie:* My daughter is my world.
   *-> Con gái là thế giới của tôi.*

## 🕸️ Mạng lưới từ (Word Network)
**Word Family:**
- Daughter-in-law (n)

**Synonyms:** Female offspring
**Antonyms:** Son
