---
tags:
  - review
  - flashcards
  - flashcards/3-People-and-Relationships/CELEBRITIES-IMPACT-ON-THE-SOCIETY
  - review/3-People-and-Relationships/CELEBRITIES-IMPACT-ON-THE-SOCIETY
---
# Reputation
*n.*
> /ˌrep.jəˈteɪ.ʃən/

![[reputation.mp3]]

---
**Level:** B2 | **Ngữ cảnh:** Academic | **Chủ đề:** CELEBRITIES' IMPACT ON THE SOCIETY | **Phân nhóm:** Truyền thông, Tin tức & Sự săn đón

## 🗂️ Flashcard
30 - Reputation::Danh tiếng *(Phát âm: /ˌrep.jəˈteɪ.ʃən/)* ![[reputation.mp3]]<br><br>👪 **Word Family:** Reputable (adj.)<br><br>💬 **Ví dụ:** Protect your reputation.<br>*(-> Bảo vệ danh tiếng của bạn.)*

## 📌 Ý nghĩa (Meaning)
- **[EN]:** The beliefs or opinions that are generally held about someone.
- **[VN]:** Danh tiếng.

## 🧠 Mẹo nhớ (Mnemonics)
💡 Reputation -> Tiếng tăm

## 🧩 Cụm từ thường đi kèm (Collocations)
- `Good reputation`: Danh tiếng tốt
- `tarnish a reputation`: làm hoen ố danh tiếng
- `enhance one's reputation`: nâng cao uy tín danh dự
- `spotless reputation`: danh tiếng không tì vết

## 🎬 Ví dụ thực tế (Real-world Examples)
1. 💬 *Daily:* Protect your reputation.
   *-> Bảo vệ danh tiếng của bạn.*
2. 💼 *Work/Academic:* Ruined reputation.
   *-> Danh tiếng bị hủy hoại.*
3. 🎬 *Media/Movie:* Build a reputation.
   *-> Xây dựng danh tiếng.*

## 🕸️ Mạng lưới từ (Word Network)
**Word Family:**
- Reputable (adj.)

**Synonyms:** Status
**Antonyms:** Disgrace
