---
tags:
  - review
  - flashcards
  - flashcards/3-People-and-Relationships/CELEBRITIES-IMPACT-ON-THE-SOCIETY
  - review/3-People-and-Relationships/CELEBRITIES-IMPACT-ON-THE-SOCIETY
---
# Privacy
*n.*
> /ˈprɪv.ə.si/

![[privacy.mp3]]

---
**Level:** B1 | **Ngữ cảnh:** Academic | **Chủ đề:** CELEBRITIES' IMPACT ON THE SOCIETY | **Phân nhóm:** Truyền thông, Tin tức & Sự săn đón

## 🗂️ Flashcard
24 - Privacy::Sự riêng tư *(Phát âm: /ˈprɪv.ə.si/)* ![[privacy.mp3]]<br><br>👪 **Word Family:** Private (adj.)<br><br>💬 **Ví dụ:** Need privacy.<br>*(-> Cần sự riêng tư.)*

## 📌 Ý nghĩa (Meaning)
- **[EN]:** The state or condition of being free from being observed.
- **[VN]:** Sự riêng tư.

## 🧠 Mẹo nhớ (Mnemonics)
💡 Privacy -> Việc cá nhân

## 🧩 Cụm từ thường đi kèm (Collocations)
- `Invasion of privacy`: Xâm phạm quyền riêng tư
- `respect someone's privacy`: tôn trọng sự riêng tư của ai
- `loss of privacy`: mất đi sự riêng tư
- `privacy violation`: sự xâm phạm quyền riêng tư

## 🎬 Ví dụ thực tế (Real-world Examples)
1. 💬 *Daily:* Need privacy.
   *-> Cần sự riêng tư.*
2. 💼 *Work/Academic:* Respect privacy.
   *-> Tôn trọng sự riêng tư.*
3. 🎬 *Media/Movie:* Protect privacy.
   *-> Bảo vệ sự riêng tư.*

## 🕸️ Mạng lưới từ (Word Network)
**Word Family:**
- Private (adj.)

**Synonyms:** Seclusion
**Antonyms:** Publicity
