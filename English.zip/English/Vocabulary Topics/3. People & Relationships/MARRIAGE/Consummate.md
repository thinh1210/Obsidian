---
tags:
  - review
  - flashcards
  - flashcards/3-People-and-Relationships/MARRIAGE
  - review/3-People-and-Relationships/MARRIAGE
---
# Consummate
*verb*
> /ˈkɒnsəmeɪt/

![[consummate.mp3]]

---
**Level:** C2 | **Ngữ cảnh:** Formal | **Chủ đề:** MARRIAGE | **Phân nhóm:** Đời sống hôn nhân, Cam kết & Vợ chồng

## 🗂️ Flashcard
Consummate::Động phòng/Hoàn tất *(Phát âm: /ˈkɒnsəmeɪt/)* ![[consummate.mp3]]<br><br>👪 **Word Family:** Consummation (noun)<br><br>💬 **Ví dụ:** The marriage was never consummated.<br>*(-> Cuộc hôn nhân đó chưa bao giờ được động phòng.)*

## 📌 Ý nghĩa (Meaning)
- **[EN]:** Make a marriage or relationship complete by having sexual intercourse.
- **[VN]:** Động phòng/Hoàn tất.

## 🧠 Mẹo nhớ (Mnemonics)
💡 Consummate - Cùng sum vầy hoàn tất.

## 🧩 Cụm từ thường đi kèm (Collocations)
- `Consummate a marriage`: Động phòng (hoàn tất hôn nhân)
- `consummation of vows`: sự hoàn tất lời thề hôn ước
- `consummate love`: tình yêu viên mãn trọn vẹn
- `legally consummate`: hoàn tất thủ tục hôn nhân hợp pháp

## 🎬 Ví dụ thực tế (Real-world Examples)
1. 💬 *Daily:* The marriage was never consummated.
   *-> Cuộc hôn nhân đó chưa bao giờ được động phòng.*
2. 💼 *Work/Academic:* Historically, failure to consummate a marriage was grounds for annulment.
   *-> Trong lịch sử, việc không hoàn tất hôn nhân là cơ sở để hủy bỏ.*
3. 🎬 *Media/Movie:* They went to the suite to consummate their love.
   *-> Họ đến phòng suite để hoàn tất tình yêu của mình.*

## 🕸️ Mạng lưới từ (Word Network)
**Word Family:**
- Consummation (noun)

**Synonyms:** Complete, finalize
**Antonyms:** Void
