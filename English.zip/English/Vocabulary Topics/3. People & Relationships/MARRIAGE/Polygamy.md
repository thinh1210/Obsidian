---
tags:
  - review
  - flashcards
  - flashcards/3-People-and-Relationships/MARRIAGE
  - review/3-People-and-Relationships/MARRIAGE
---
# Polygamy
*noun*
> /pəˈlɪɡəmi/

![[polygamy.mp3]]

---
**Level:** C1 | **Ngữ cảnh:** Academic | **Chủ đề:** MARRIAGE | **Phân nhóm:** Bất đồng, Ly hôn & Ràng buộc pháp lý

## 🗂️ Flashcard
Polygamy::Chế độ đa thê/đa phu *(Phát âm: /pəˈlɪɡəmi/)* ![[polygamy.mp3]]<br><br>👪 **Word Family:** Polygamous (adjective)<br><br>💬 **Ví dụ:** Polygamy is illegal in this country.<br>*(-> Chế độ đa thê là bất hợp pháp ở quốc gia này.)*

## 📌 Ý nghĩa (Meaning)
- **[EN]:** The practice or custom of having more than one wife or husband at the same time.
- **[VN]:** Chế độ đa thê/đa phu.

## 🧠 Mẹo nhớ (Mnemonics)
💡 Poly (nhiều) + Gamy (hôn nhân).

## 🧩 Cụm từ thường đi kèm (Collocations)
- `Practice polygamy`: Thực hành chế độ đa phu/thê
- `outlaw polygamy`: cấm chế độ đa thê / đa phu
- `oppose polygamy`: phản đối chế độ đa thê
- `history of polygamy`: lịch sử của chế độ đa phu thê

## 🎬 Ví dụ thực tế (Real-world Examples)
1. 💬 *Daily:* Polygamy is illegal in this country.
   *-> Chế độ đa thê là bất hợp pháp ở quốc gia này.*
2. 💼 *Work/Academic:* Historical texts document the practice of polygamy.
   *-> Các văn bản lịch sử ghi chép lại việc thực hành chế độ đa phu thê.*
3. 🎬 *Media/Movie:* He was arrested for polygamy.
   *-> Anh ta đã bị bắt vì chế độ đa thê.*

## 🕸️ Mạng lưới từ (Word Network)
**Word Family:**
- Polygamous (adjective)

**Synonyms:** Plural marriage
**Antonyms:** Monogamy
