---
tags:
  - review
  - flashcards
  - flashcards/3-People-and-Relationships/MARRIAGE
  - review/3-People-and-Relationships/MARRIAGE
---
# Spouse
*noun*
> /spaʊs/

![[spouse.mp3]]

---
**Level:** B2 | **Ngữ cảnh:** Formal | **Chủ đề:** MARRIAGE | **Phân nhóm:** Đời sống hôn nhân, Cam kết & Vợ chồng

## 🗂️ Flashcard
Spouse::Vợ hoặc chồng *(Phát âm: /spaʊs/)* ![[spouse.mp3]]<br><br>👪 **Word Family:** Spousal (adjective)<br><br>💬 **Ví dụ:** Employees can bring their spouses.<br>*(-> Nhân viên có thể đưa vợ/chồng của họ đi cùng.)*

## 📌 Ý nghĩa (Meaning)
- **[EN]:** A husband or wife, considered in relation to their partner.
- **[VN]:** Vợ hoặc chồng.

## 🧠 Mẹo nhớ (Mnemonics)
💡 Spouse - Sếp (trong nhà).

## 🧩 Cụm từ thường đi kèm (Collocations)
- `A surviving spouse`: Người vợ/chồng còn sống
- `supportive spouse`: người phối ngẫu luôn kề vai sát cánh
- `devoted spouse`: người vợ/chồng tận tụy chu đáo
- `spouse's consent`: sự đồng thuận của người bạn đời

## 🎬 Ví dụ thực tế (Real-world Examples)
1. 💬 *Daily:* Employees can bring their spouses.
   *-> Nhân viên có thể đưa vợ/chồng của họ đi cùng.*
2. 💼 *Work/Academic:* Spouses are eligible for benefits.
   *-> Vợ/chồng có đủ điều kiện nhận phúc lợi.*
3. 🎬 *Media/Movie:* Meet my beautiful spouse.
   *-> Hãy gặp người vợ xinh đẹp của tôi.*

## 🕸️ Mạng lưới từ (Word Network)
**Word Family:**
- Spousal (adjective)

**Synonyms:** Partner, mate
**Antonyms:** None
