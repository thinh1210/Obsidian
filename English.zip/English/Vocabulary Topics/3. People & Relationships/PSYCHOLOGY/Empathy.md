---
tags:
  - review
  - flashcards
  - flashcards/3-People-and-Relationships/PSYCHOLOGY
  - review/3-People-and-Relationships/PSYCHOLOGY
---
# Empathy
*noun*
> /ˈem.pə.θi/

![[empathy.mp3]]

---
**Level:** B2 | **Ngữ cảnh:** Work | **Chủ đề:** PSYCHOLOGY | **Phân nhóm:** Cảm xúc, Tính cách & Động lực

## 🗂️ Flashcard
Empathy::Sự thấu cảm *(Phát âm: /ˈem.pə.θi/)* ![[empathy.mp3]]<br><br>👪 **Word Family:** empathetic (adj)<br><br>💬 **Ví dụ:** You need to have empathy.<br>*(-> Bạn cần có sự thấu cảm.)*

## 📌 Ý nghĩa (Meaning)
- **EN:** The ability to understand and share the feelings of another.
- **VN:** Sự thấu cảm

## 🧠 Mẹo nhớ (Mnemonics)
💡 Empathy = Em ba thi (em thấu hiểu).

## 🧩 Cụm từ thường đi kèm (Collocations)
- `show empathy`: thể hiện sự thấu cảm
- `deep empathy`: sự thấu cảm sâu sắc
- `lack empathy`: thiếu sự đồng cảm thương người
- `empathy gap`: khoảng cách thiếu thấu cảm

## 🎬 Ví dụ thực tế (Real-world Examples)
1. 💬 *Daily:* You need to have empathy.
   *-> Bạn cần có sự thấu cảm.*
2. 💼 *Work/Academic:* Empathy is a vital leadership trait.
   *-> Sự thấu cảm là đặc điểm lãnh đạo quan trọng.*
3. 🎬 *Media/Movie:* He feels no empathy for them.
   *-> Anh ta không cảm thấy thấu cảm với họ.*

## 🕸️ Mạng lưới từ (Word Network)
**Word Family:**
- empathetic (adj)

**Synonyms:** compassion, sympathy
**Antonyms:** apathy
