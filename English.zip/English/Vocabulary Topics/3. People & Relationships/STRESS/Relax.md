---
tags:
  - review
  - flashcards
  - flashcards/3-People-and-Relationships/STRESS
  - review/3-People-and-Relationships/STRESS
---
# Relax
*v.*
> /rɪˈlæks/

![[relax.mp3]]

---
**Level:** A2 | **Ngữ cảnh:** Daily | **Chủ đề:** STRESS | **Phân nhóm:** Kiểm soát, Đối phó & Tìm lại cân bằng

## 🗂️ Flashcard
Relax::Thư giãn *(Phát âm: /rɪˈlæks/)* ![[relax.mp3]]<br><br>👪 **Word Family:** relaxation (n), relaxing (adj)<br><br>💬 **Ví dụ:** I want to relax this weekend.<br>*(-> Tôi muốn thư giãn cuối tuần này.)*

## 📌 Ý nghĩa (Meaning)
- **[EN]:** To rest and become calm
- **[VN]:** Thư giãn

## 🧠 Mẹo nhớ (Mnemonics)
💡 Re (lại) + lax (lắc): lắc lư cơ thể để thư giãn lại

## 🧩 Cụm từ thường đi kèm (Collocations)
- `just relax`: cứ thư giãn đi
- `relax completely`: thư giãn hoàn toàn
- `relax muscles`: thả lỏng các cơ bắp
- `relaxed pace`: nhịp sống thư thái thong thả

## 🎬 Ví dụ thực tế (Real-world Examples)
1. 💬 *Daily:* I want to relax this weekend.
   *-> Tôi muốn thư giãn cuối tuần này.*
2. 💼 *Work/Academic:* We need to relax the rules.
   *-> Chúng ta cần nới lỏng các quy định.*
3. 🎬 *Media/Movie:* Relax, man! It's going to be okay.
   *-> Thư giãn đi anh bạn! Mọi chuyện sẽ ổn thôi.*

## 🕸️ Mạng lưới từ (Word Network)
**Word Family:**
- relaxation (n), relaxing (adj)

**Synonyms:** rest, chill
**Antonyms:** stress, worry\n
