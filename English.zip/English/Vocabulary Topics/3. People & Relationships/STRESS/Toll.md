---
tags:
  - review
  - flashcards
  - flashcards/3-People-and-Relationships/STRESS
  - review/3-People-and-Relationships/STRESS
---
# Toll
*n.*
> /təʊl/

![[toll.mp3]]

---
**Level:** C1 | **Ngữ cảnh:** Work | **Chủ đề:** STRESS | **Phân nhóm:** Biểu hiện thể chất, Kiệt sức & Hoảng loạn

## 🗂️ Flashcard
Toll::Sự tổn thất, hậu quả xấu *(Phát âm: /təʊl/)* ![[toll.mp3]]<br><br>👪 **Word Family:** N/A<br><br>💬 **Ví dụ:** The stress took a toll on her health.<br>*(-> Căng thẳng đã gây tổn thất cho sức khỏe của cô ấy.)*

## 📌 Ý nghĩa (Meaning)
- **[EN]:** The adverse effect of something
- **[VN]:** Sự tổn thất, hậu quả xấu

## 🧠 Mẹo nhớ (Mnemonics)
💡 Tô - ăn một tô bún bị tính phí tổn thất cao

## 🧩 Cụm từ thường đi kèm (Collocations)
- `take a toll on`: gây tổn thất cho
- `heavy toll`: tổn thất nặng nề
- `take its toll`: để lại hậu quả tổn hại nghiêm trọng
- `exact a heavy toll`: đòi hỏi cái giá quá đắt

## 🎬 Ví dụ thực tế (Real-world Examples)
1. 💬 *Daily:* The stress took a toll on her health.
   *-> Căng thẳng đã gây tổn thất cho sức khỏe của cô ấy.*
2. 💼 *Work/Academic:* Years of inflation have taken a toll on the economy.
   *-> Nhiều năm lạm phát đã gây tổn thất cho nền kinh tế.*
3. 🎬 *Media/Movie:* The war took a heavy toll.
   *-> Cuộc chiến đã lấy đi một tổn thất nặng nề.*

## 🕸️ Mạng lưới từ (Word Network)
**Word Family:**
- N/A

**Synonyms:** damage, harm
**Antonyms:** benefit\n
