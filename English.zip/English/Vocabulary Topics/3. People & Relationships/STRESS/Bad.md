---
tags:
  - review
  - flashcards
  - flashcards/3-People-and-Relationships/STRESS
  - review/3-People-and-Relationships/STRESS
---
# Bad
*adj.*
> /bæd/

![[bad.mp3]]

---
**Level:** A1 | **Ngữ cảnh:** Daily | **Chủ đề:** STRESS | **Phân nhóm:** Tác động tâm lý, Cảm xúc tiêu cực & Suy sụp

## 🗂️ Flashcard
Bad::Tệ, xấu *(Phát âm: /bæd/)* ![[bad.mp3]]<br><br>👪 **Word Family:** badly (adv), badness (n)<br><br>💬 **Ví dụ:** I had a bad day.<br>*(-> Tôi đã có một ngày tồi tệ.)*

## 📌 Ý nghĩa (Meaning)
- **[EN]:** Not good, unpleasant
- **[VN]:** Tệ, xấu

## 🧠 Mẹo nhớ (Mnemonics)
💡 Bát - làm vỡ bát là điều tồi tệ

## 🧩 Cụm từ thường đi kèm (Collocations)
- `bad day`: một ngày tồi tệ
- `feel bad`: cảm thấy tồi tệ
- `bad habit`: thói quen xấu
- `from bad to worse`: ngày càng tồi tệ hơn (idiom)

## 🎬 Ví dụ thực tế (Real-world Examples)
1. 💬 *Daily:* I had a bad day.
   *-> Tôi đã có một ngày tồi tệ.*
2. 💼 *Work/Academic:* The economy is in a bad state.
   *-> Nền kinh tế đang ở trong tình trạng tồi tệ.*
3. 🎬 *Media/Movie:* I got a bad feeling about this.
   *-> Tôi có dự cảm không lành về chuyện này.*

## 🕸️ Mạng lưới từ (Word Network)
**Word Family:**
- badly (adv), badness (n)

**Synonyms:** terrible, awful
**Antonyms:** good, great\n
