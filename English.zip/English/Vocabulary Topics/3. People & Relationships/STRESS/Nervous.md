---
tags:
  - review
  - flashcards
  - flashcards/3-People-and-Relationships/STRESS
  - review/3-People-and-Relationships/STRESS
---
# Nervous
*adj.*
> /ˈnɜːrvəs/

![[nervous.mp3]]

---
**Level:** B1 | **Ngữ cảnh:** Daily | **Chủ đề:** STRESS | **Phân nhóm:** Tác động tâm lý, Cảm xúc tiêu cực & Suy sụp

## 🗂️ Flashcard
Nervous::Căng thẳng, hồi hộp *(Phát âm: /ˈnɜːrvəs/)* ![[nervous.mp3]]<br><br>👪 **Word Family:** nervously (adv), nervousness (n)<br><br>💬 **Ví dụ:** I always get nervous before exams.<br>*(-> Tôi luôn thấy hồi hộp trước các kỳ thi.)*

## 📌 Ý nghĩa (Meaning)
- **[EN]:** Easily agitated or alarmed; tending to be anxious
- **[VN]:** Căng thẳng, hồi hộp

## 🧠 Mẹo nhớ (Mnemonics)
💡 Nơ vớt - cái nơ rớt làm cô bé hồi hộp

## 🧩 Cụm từ thường đi kèm (Collocations)
- `feel nervous`: cảm thấy hồi hộp
- `nervous system`: hệ thần kinh
- `nervous wreck`: người bị kiệt quệ thần kinh vì căng thẳng (idiom)
- `nervous breakdown`: suy nhược thần kinh

## 🎬 Ví dụ thực tế (Real-world Examples)
1. 💬 *Daily:* I always get nervous before exams.
   *-> Tôi luôn thấy hồi hộp trước các kỳ thi.*
2. 💼 *Work/Academic:* Public speaking makes many professionals nervous.
   *-> Nói trước công chúng làm nhiều chuyên gia hồi hộp.*
3. 🎬 *Media/Movie:* Why are you so nervous?
   *-> Sao cậu lại lo lắng thế?*

## 🕸️ Mạng lưới từ (Word Network)
**Word Family:**
- nervously (adv), nervousness (n)

**Synonyms:** anxious, tense
**Antonyms:** calm, relaxed\n
