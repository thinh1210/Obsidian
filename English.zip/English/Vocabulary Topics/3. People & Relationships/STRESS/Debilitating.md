---
tags:
  - review
  - flashcards
  - flashcards/3-People-and-Relationships/STRESS
  - review/3-People-and-Relationships/STRESS
---
# Debilitating
*adj.*
> /dɪˈbɪlɪteɪtɪŋ/

![[debilitating.mp3]]

---
**Level:** C2 | **Ngữ cảnh:** Academic | **Chủ đề:** STRESS | **Phân nhóm:** Biểu hiện thể chất, Kiệt sức & Hoảng loạn

## 🗂️ Flashcard
Debilitating::Làm suy nhược *(Phát âm: /dɪˈbɪlɪteɪtɪŋ/)* ![[debilitating.mp3]]<br><br>👪 **Word Family:** debilitate (v), debilitation (n)<br><br>💬 **Ví dụ:** She has a debilitating illness.<br>*(-> Cô ấy mắc một căn bệnh làm suy nhược.)*

## 📌 Ý nghĩa (Meaning)
- **[EN]:** Making someone very weak and infirm
- **[VN]:** Làm suy nhược

## 🧠 Mẹo nhớ (Mnemonics)
💡 Đề bi lì tới tình - bị đề một cục bi lì lợm lên người làm suy nhược

## 🧩 Cụm từ thường đi kèm (Collocations)
- `debilitating disease`: căn bệnh suy nhược
- `debilitating effect`: tác động làm suy yếu
- `debilitating condition`: tình trạng suy nhược thể chất
- `debilitating anxiety`: sự lo âu làm tê liệt tinh thần

## 🎬 Ví dụ thực tế (Real-world Examples)
1. 💬 *Daily:* She has a debilitating illness.
   *-> Cô ấy mắc một căn bệnh làm suy nhược.*
2. 💼 *Work/Academic:* The country suffered a debilitating economic crisis.
   *-> Đất nước phải chịu một cuộc khủng hoảng kinh tế suy nhược.*
3. 🎬 *Media/Movie:* The fear was debilitating.
   *-> Nỗi sợ hãi làm suy yếu cả con người.*

## 🕸️ Mạng lưới từ (Word Network)
**Word Family:**
- debilitate (v), debilitation (n)

**Synonyms:** weakening, disabling
**Antonyms:** invigorating, strengthening\n
