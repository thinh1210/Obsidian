---
tags:
  - review
  - flashcards
  - flashcards/3-People-and-Relationships/STRESS
  - review/3-People-and-Relationships/STRESS
---
# Exhausted
*adj.*
> /ɪɡˈzɔːstɪd/

![[exhausted.mp3]]

---
**Level:** B1 | **Ngữ cảnh:** Daily | **Chủ đề:** STRESS | **Phân nhóm:** Biểu hiện thể chất, Kiệt sức & Hoảng loạn

## 🗂️ Flashcard
Exhausted::Kiệt sức *(Phát âm: /ɪɡˈzɔːstɪd/)* ![[exhausted.mp3]]<br><br>👪 **Word Family:** exhaust (v), exhaustion (n)<br><br>💬 **Ví dụ:** I am exhausted after the trip.<br>*(-> Tôi kiệt sức sau chuyến đi.)*

## 📌 Ý nghĩa (Meaning)
- **[EN]:** Extremely tired
- **[VN]:** Kiệt sức

## 🧠 Mẹo nhớ (Mnemonics)
💡 Xót (xhaust) ruột vì mệt lả

## 🧩 Cụm từ thường đi kèm (Collocations)
- `feel exhausted`: cảm thấy kiệt sức
- `completely exhausted`: hoàn toàn kiệt sức
- `exhausted physically and mentally`: kiệt sức cả thể xác lẫn tinh thần
- `exhaust all possibilities`: thử hết mọi khả năng phương án

## 🎬 Ví dụ thực tế (Real-world Examples)
1. 💬 *Daily:* I am exhausted after the trip.
   *-> Tôi kiệt sức sau chuyến đi.*
2. 💼 *Work/Academic:* The team was exhausted from the long meeting.
   *-> Nhóm đã kiệt sức sau cuộc họp dài.*
3. 🎬 *Media/Movie:* You look exhausted, go to bed.
   *-> Trông bạn kiệt sức rồi, đi ngủ đi.*

## 🕸️ Mạng lưới từ (Word Network)
**Word Family:**
- exhaust (v), exhaustion (n)

**Synonyms:** tired, drained
**Antonyms:** energetic, refreshed\n
